package ar.org.centro8.curso.java.proyectofinal.test;

import java.sql.Connection;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Alumno;
import ar.org.centro8.curso.java.proyectofinal.entities.Curso;
import ar.org.centro8.curso.java.proyectofinal.enums.Dia;
import ar.org.centro8.curso.java.proyectofinal.enums.Turno;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.AlumnoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        Connection conn=Connector.getConnection();
        I_CursoRepository cursoRepository=new CursoRepository(conn);
        Curso curso=new Curso("Jardineria","Torres",Dia.LUNES,Turno.TARDE);
        cursoRepository.save(curso);
        System.out.println(curso);

        //curso=cursoRepository.getById(2);
        //cursoRepository.remove(curso);
        cursoRepository.remove(cursoRepository.getById(3));

        curso=cursoRepository.getById(5);
        if(curso!=null && curso.getId()!=0){
            curso.setTitulo("java");
            curso.setProfesor("Rios");
            cursoRepository.update(curso);
        }

        System.out.println("**************************************");
        cursoRepository.getAll().forEach(System.out::println);

        System.out.println("**************************************");
        cursoRepository
            .getLikeProfesor("tor")
            .forEach(System.out::println);
        System.out.println("**************************************");
        cursoRepository
            .getLikeTitulo("ja")
            .forEach(System.out::println);

        System.out.println("**************************************");    
        I_AlumnoRepository alumnoRepository=new AlumnoRepository(conn);
        Alumno alumno=new Alumno("Laura","Salinas",26,1);
        alumnoRepository.save(alumno);
        System.out.println(alumno);

        alumnoRepository.remove(alumnoRepository.getById(2));

        alumno=alumnoRepository.getById(4);
        if(alumno!=null){
            alumno.setIdCurso(20);
            alumnoRepository.update(alumno);
        }

        System.out.println("**************************************");  
        alumnoRepository.getAll().forEach(System.out::println);
        System.out.println("**************************************"); 
        alumnoRepository
            .getLikeCurso(cursoRepository.getById(1))
            .forEach(System.out::println);

    }
}
