package ar.org.centro8.curso.java.proyectofinal.utils.sumar;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class SumarTest {
    Sumar sumar=new Sumar();
    @Test
    void testSumar1() {
        assertEquals(sumar.sumar(2, 2), 4);
    }

    @Test
    void testSumar2() {
        assertEquals(sumar.sumar(2, 0), 2);
    }

    @Test
    void testSumar3() {
        assertEquals(sumar.sumar(-2, -2), -4);  
    }

    @Test
    void testSumar4() {
        assertEquals(sumar.sumar(-2, 2), 0);
    }

    @Test
    void testSumar5() {
        assertEquals(sumar.sumar(2, -2), 0);
    }
}
