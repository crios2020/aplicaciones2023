package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Curso;
import ar.org.centro8.curso.java.proyectofinal.enums.Dia;
import ar.org.centro8.curso.java.proyectofinal.enums.Turno;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_CursoRepository;

public class CursoRepositoryTest {

    I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());

    @Test
    void testSave() {
        Curso curso1=new Curso("xxx","xxx",Dia.LUNES,Turno.TARDE);
        Curso curso2=new Curso("xxx","xxx",Dia.LUNES,Turno.TARDE);
        cursoRepository.save(curso1);
        cursoRepository.save(curso2);

        assertEquals(curso1.getId()>0, true);
        assertEquals(curso1.getId(), curso2.getId()-1);
    }

    @Test
    void testGetAll() {
        assertEquals(cursoRepository.getAll().size()>=2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial=cursoRepository.getAll().size();
        cursoRepository.remove(cursoRepository.getAll().get(cantidadInicial-1));
        int cantidadFinal=cursoRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal+1);
    }

    @Test
    void testUpdate() {
        int cantidad=cursoRepository.getAll().size();
        Curso curso=cursoRepository.getAll().get(cantidad-1);
        curso.setTitulo("ooo");
        curso.setProfesor("ooo");
        curso.setDia(Dia.VIERNES);
        curso.setTurno(Turno.NOCHE);
        cursoRepository.update(curso);
        Curso curso2=cursoRepository.getAll().get(cantidad-1);

        assertEquals(curso.getTitulo(), curso2.getTitulo());
        assertEquals(curso.getProfesor(), curso2.getProfesor());
        assertEquals(curso.getDia(), curso2.getDia());
        assertEquals(curso.getTurno(), curso2.getTurno());

    }
}
